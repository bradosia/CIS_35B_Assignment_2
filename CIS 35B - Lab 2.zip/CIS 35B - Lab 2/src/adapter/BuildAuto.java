package adapter;

public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto {
	
}
